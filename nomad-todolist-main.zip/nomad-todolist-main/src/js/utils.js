function getRandomNumber(max) {
    return Math.floor(Math.random() * max);
}
